'use strict';

const c = require('c');

function init() {
  c.init();
}

module.exports = {
  init
}
