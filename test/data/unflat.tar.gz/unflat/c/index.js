'use strict';

const d = require('d');
const e = require('e');

function init() {
  d.init();
  e.init();
}

module.exports = {
  init
}
