'use strict';

const b = require('b');

function init() {
  b.init();
}

module.exports = {
  init
}
