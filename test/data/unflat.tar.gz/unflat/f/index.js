'use strict';

function init() {
  return 2;
}

module.exports = {
  init
}
