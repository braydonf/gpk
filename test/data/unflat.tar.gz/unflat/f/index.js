'use strict';

function init() {
  return 1;
}

module.exports = {
  init
}
