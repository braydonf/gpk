'use strict';

const f = require('f');

function init() {
  f.init();
}

module.exports {
  init
}
