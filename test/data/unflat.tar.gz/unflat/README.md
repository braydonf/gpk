# Unflat

The dependency graph:
```
a@1.0.0
  ↳ b@1.0.0
    ↳ c@1.0.0
      ↳ d@1.0.0
        ↳ f@1.0.0
      ↳ e@1.0.0
        ↳ f@1.0.0
  ↳ c@2.0.0
    ↳ d@2.0.0
      ↳ f@2.0.0
    ↳ e@2.0.0
      ↳ f@2.0.0
  ↳ f@1.0.0
```

Should result in a flattened `node_modules` directory layout:

```
node_modules
  ↳ b@1.0.0
    ↳ node_modules
      ↳ c@1.0.0
  ↳ c2.0.0
    ↳ node_modules
      ↳ d@2.0.0
      ↳ e@2.0.0
      ↳ f@2.0.0
  ↳ d@1.0.0
  ↳ e@1.0.0
  ↳ f@1.0.0
```
